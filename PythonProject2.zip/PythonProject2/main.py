import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, timedelta
import json # Импортируем библиотеку для работы с JSON
import os # Для проверки существования файла

# --- Константы ---
TASKS_FILE = "taskpy.json" # Имя файла для сохранения задач

class DailyPlannerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ежедневник")
        self.root.geometry("800x600")

        self.tasks = []  # Список для хранения задач: (дата_str, время_str, текст_задачи)
        self.current_date = datetime.now()

        self.load_tasks_from_json() # Загружаем задачи из файла при старте
        self.create_widgets()
        self.update_date_label()
        self.update_task_display()
        self.check_scheduled_tasks()

        # Удалена проблемная строка: self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        # Tkinter сам вызовет on_closing при закрытии окна.


    def create_widgets(self):
        # --- Верхняя панель (навигация по дням) ---
        top_frame = ttk.Frame(self.root, padding="10")
        top_frame.pack(fill=tk.X)

        ttk.Label(top_frame, text="Выберите день:").pack(side=tk.LEFT, padx=5)

        self.prev_day_button = ttk.Button(top_frame, text="<", command=self.prev_day)
        self.prev_day_button.pack(side=tk.LEFT, padx=2)

        self.date_label = ttk.Label(top_frame, text="", font=("Arial", 12, "bold"))
        self.date_label.pack(side=tk.LEFT, padx=5)

        self.next_day_button = ttk.Button(top_frame, text=">", command=self.next_day)
        self.next_day_button.pack(side=tk.LEFT, padx=2)

        # --- Левая панель (ввод задач) ---
        left_frame = ttk.Frame(self.root, padding="10")
        left_frame.pack(side=tk.LEFT, fill=tk.Y, expand=False)

        ttk.Label(left_frame, text="Добавить задачу:", font=("Arial", 10, "bold")).pack(pady=5)

        ttk.Label(left_frame, text="Время (ЧЧ:ММ):").pack(anchor=tk.W)
        self.time_entry = ttk.Entry(left_frame, width=10)
        self.time_entry.pack(anchor=tk.W, pady=2)
        self.time_entry.insert(0, datetime.now().strftime("%H:%M")) # Предзаполнение текущим временем

        ttk.Label(left_frame, text="Задача:").pack(anchor=tk.W, pady=(10, 0))
        self.task_text_entry = tk.Text(left_frame, height=5, width=30)
        self.task_text_entry.pack(anchor=tk.W, pady=2)

        self.add_task_button = ttk.Button(left_frame, text="Добавить задачу", command=self.add_task)
        self.add_task_button.pack(pady=10)

        # --- Правая панель (список задач на день) ---
        right_frame = ttk.Frame(self.root, padding="10")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        ttk.Label(right_frame, text="Задачи на сегодня:", font=("Arial", 10, "bold")).pack(pady=5)

        self.task_listbox = tk.Listbox(right_frame, height=15, width=50, font=("Arial", 10))
        self.task_listbox.pack(fill=tk.BOTH, expand=True)

        # --- Статус бар ---
        status_frame = ttk.Frame(self.root, padding="5")
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Label(status_frame, text=f"Планировщик запущен. Задачи сохраняются в {TASKS_FILE}").pack(side=tk.LEFT)

    def update_date_label(self):
        """Обновляет метку с текущей датой."""
        day_name = self.current_date.strftime("%A") # Полное название дня недели
        date_str = self.current_date.strftime("%d.%m.%Y")
        self.date_label.config(text=f"{day_name}, {date_str}")

    def update_task_display(self):
        """Отображает задачи для выбранного дня."""
        self.task_listbox.delete(0, tk.END)
        today_str = self.current_date.strftime("%Y-%m-%d")
        # Фильтруем задачи по выбранной дате и сортируем по времени
        tasks_for_today = sorted([task for task in self.tasks if task[0] == today_str], key=lambda x: x[1])

        if not tasks_for_today:
            self.task_listbox.insert(tk.END, "Нет запланированных задач.")
        else:
            for task_date_str, task_time, task_text in tasks_for_today:
                self.task_listbox.insert(tk.END, f"{task_time}: {task_text}")

    def prev_day(self):
        self.current_date -= timedelta(days=1)
        self.update_date_label()
        self.update_task_display()

    def next_day(self):
        self.current_date += timedelta(days=1)
        self.update_date_label()
        self.update_task_display()

    def add_task(self):
        task_time_str = self.time_entry.get().strip()
        task_text = self.task_text_entry.get("1.0", tk.END).strip() # Читаем текст из Text виджета

        if not task_time_str or not task_text:
            messagebox.showwarning("Ошибка", "Пожалуйста, введите время и текст задачи.")
            return

        try:
            # Проверка формата времени
            datetime.strptime(task_time_str, "%H:%M")
        except ValueError:
            messagebox.showwarning("Ошибка", "Неверный формат времени. Используйте ЧЧ:ММ (например, 19:00).")
            return

        task_date_str = self.current_date.strftime("%Y-%m-%d")
        new_task = (task_date_str, task_time_str, task_text)
        self.tasks.append(new_task)
        self.tasks.sort(key=lambda x: (x[0], x[1])) # Сортируем по дате и времени

        self.save_tasks_to_json() # Сохраняем после добавления

        # Обновляем список задач, если выбрана текущая дата
        if self.current_date.date() == datetime.now().date():
            self.update_task_display()

        # Очищаем поля ввода
        self.time_entry.delete(0, tk.END)
        self.task_text_entry.delete("1.0", tk.END)
        self.time_entry.insert(0, datetime.now().strftime("%H:%M")) # Предзаполнение новым текущим временем

        messagebox.showinfo("Успех", "Задача добавлена и сохранена!")

    def check_scheduled_tasks(self):
        """Проверяет, не наступило ли время для каких-либо задач."""
        now = datetime.now()
        current_date_str = now.strftime("%Y-%m-%d")
        current_time_str = now.strftime("%H:%M")

        tasks_to_remove = [] # Список задач, которые нужно удалить после проверки
        for task_data in self.tasks:
            task_date_str, task_time, task_text = task_data

            if task_date_str == current_date_str and task_time == current_time_str:
                tasks_to_remove.append(task_data)
                self.show_notification(f"Вы планировали в назначенную дату ({task_date_str}) в {task_time}: {task_text}")

        # Удаляем выполненные задачи
        if tasks_to_remove:
            self.tasks = [task for task in self.tasks if task not in tasks_to_remove]
            self.save_tasks_to_json() # Сохраняем после удаления

            # Если мы удалили задачу, нужно обновить отображение, если это сегодняшний день
            if self.current_date.date() == datetime.now().date():
                self.update_task_display()

        # Планируем следующую проверку через 1 минуту (60000 миллисекунд)
        self.root.after(60000, self.check_scheduled_tasks)

    def show_notification(self, message):
        """Имитирует уведомление."""
        messagebox.showinfo("Напоминание!", message)

    def save_tasks_to_json(self):
        """Сохраняет текущий список задач в JSON файл."""
        try:
            with open(TASKS_FILE, 'w', encoding='utf-8') as f:
                # JSON не может напрямую сериализовать кортежи, поэтому конвертируем в списки
                json_tasks = [list(task) for task in self.tasks]
                json.dump(json_tasks, f, ensure_ascii=False, indent=4)
        except Exception as e:
            messagebox.showerror("Ошибка сохранения", f"Не удалось сохранить задачи в файл {TASKS_FILE}:\n{e}")

    def load_tasks_from_json(self):
        """Загружает задачи из JSON файла."""
        if not os.path.exists(TASKS_FILE):
            return # Если файла нет, просто выходим

        try:
            with open(TASKS_FILE, 'r', encoding='utf-8') as f:
                json_tasks = json.load(f)
                # Конвертируем списки обратно в кортежи
                self.tasks = [tuple(task) for task in json_tasks]
                # Сортируем после загрузки, чтобы быть уверенными
                self.tasks.sort(key=lambda x: (x[0], x[1]))
        except json.JSONDecodeError:
            messagebox.showerror("Ошибка загрузки", f"Файл {TASKS_FILE} поврежден или имеет неверный формат JSON.")
            self.tasks = [] # Очищаем список, если файл поврежден
        except Exception as e:
            messagebox.showerror("Ошибка загрузки", f"Не удалось загрузить задачи из файла {TASKS_FILE}:\n{e}")
            self.tasks = []

    def on_closing(self):
        """Обработчик закрытия окна."""
        # В данном случае, сохранение происходит при добавлении/удалении,
        # так что финальное сохранение здесь не строго обязательно.
        # Но если бы оно было нужно, то здесь:
        # self.save_tasks_to_json()
        self.root.destroy() # Закрываем окно

    def run(self):
        self.update_date_label()
        self.root.mainloop()

if __name__ == "__main__":
    root = tk.Tk()
    app = DailyPlannerApp(root)
    app.run()